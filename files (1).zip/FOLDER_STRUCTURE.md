# LeetCode AI Mentor - Complete Folder Structure

```
leetcode-ai-mentor/
│
├── app/
│   ├── layout.tsx                    # Root layout
│   ├── page.tsx                      # Landing page
│   ├── dashboard/
│   │   ├── page.tsx                  # Dashboard home
│   │   ├── problems/
│   │   │   ├── page.tsx              # Problem solver page
│   │   │   ├── [id]/
│   │   │   │   └── page.tsx          # Individual problem detail
│   │   ├── hints/
│   │   │   └── page.tsx              # Hint generator
│   │   ├── analyzer/
│   │   │   └── page.tsx              # Code analyzer
│   │   ├── interview/
│   │   │   └── page.tsx              # Interview mode
│   │   ├── roadmap/
│   │   │   └── page.tsx              # Learning roadmap
│   │   ├── bookmarks/
│   │   │   └── page.tsx              # Saved problems
│   │   └── profile/
│   │       └── page.tsx              # User profile
│   ├── api/
│   │   ├── auth/
│   │   │   ├── callback/
│   │   │   │   └── route.ts          # OAuth callback
│   │   │   └── route.ts              # Auth endpoints
│   │   ├── ai/
│   │   │   ├── solve/
│   │   │   │   └── route.ts          # Problem solver AI
│   │   │   ├── hints/
│   │   │   │   └── route.ts          # Hint generator
│   │   │   ├── analyze/
│   │   │   │   └── route.ts          # Code analyzer
│   │   │   ├── interview/
│   │   │   │   └── route.ts          # Interview questions
│   │   │   └── roadmap/
│   │   │       └── route.ts          # Roadmap generator
│   │   ├── problems/
│   │   │   ├── route.ts              # CRUD for problems
│   │   │   └── [id]/route.ts         # Individual problem endpoints
│   │   ├── solutions/
│   │   │   ├── route.ts              # Save/get solutions
│   │   │   └── [id]/route.ts         # Individual solution
│   │   ├── bookmarks/
│   │   │   └── route.ts              # Bookmark management
│   │   ├── progress/
│   │   │   └── route.ts              # Progress tracking
│   │   ├── achievements/
│   │   │   └── route.ts              # Achievement system
│   │   └── user/
│   │       └── route.ts              # User profile data
│   └── auth/
│       ├── page.tsx                  # Login/signup page
│       └── callback/
│           └── page.tsx              # Auth callback handler
│
├── components/
│   ├── layout/
│   │   ├── Navbar.tsx
│   │   ├── Sidebar.tsx
│   │   ├── ThemeToggle.tsx
│   │   └── Footer.tsx
│   ├── dashboard/
│   │   ├── StatsCard.tsx
│   │   ├── ProgressChart.tsx
│   │   ├── AchievementBadge.tsx
│   │   └── ActivityFeed.tsx
│   ├── problem-solver/
│   │   ├── ProblemInput.tsx
│   │   ├── ProblemExplanation.tsx
│   │   ├── SolutionDisplay.tsx
│   │   └── ComplexityAnalysis.tsx
│   ├── hint-generator/
│   │   ├── HintLevels.tsx
│   │   └── HintDisplay.tsx
│   ├── code-analyzer/
│   │   ├── CodeInput.tsx
│   │   ├── AnalysisResult.tsx
│   │   └── LanguageSelector.tsx
│   ├── interview-mode/
│   │   ├── QuestionCard.tsx
│   │   ├── AnswerInput.tsx
│   │   └── FeedbackDisplay.tsx
│   ├── learning-roadmap/
│   │   ├── TopicCard.tsx
│   │   ├── ProgressBar.tsx
│   │   └── RoadmapPath.tsx
│   ├── bookmarks/
│   │   ├── BookmarkCard.tsx
│   │   └── FolderManager.tsx
│   ├── common/
│   │   ├── Button.tsx
│   │   ├── Card.tsx
│   │   ├── Modal.tsx
│   │   ├── Loading.tsx
│   │   └── Toast.tsx
│   └── ui/
│       └── (ShadCN components)
│
├── lib/
│   ├── supabase.ts                   # Supabase client
│   ├── openai.ts                     # OpenAI client
│   ├── auth.ts                       # Auth helpers
│   ├── db.ts                         # Database queries
│   ├── types.ts                      # TypeScript types
│   ├── constants.ts                  # Constants
│   ├── utils.ts                      # Utility functions
│   ├── ai-prompts.ts                 # AI prompt templates
│   └── hooks/
│       ├── useAuth.ts
│       ├── useProblems.ts
│       ├── useSolutions.ts
│       └── useProgress.ts
│
├── styles/
│   ├── globals.css
│   ├── variables.css                 # CSS variables for theming
│   └── animations.css                # Framer Motion + custom animations
│
├── public/
│   ├── icons/
│   ├── images/
│   └── assets/
│
├── .env.local                        # Environment variables (local)
├── .env.example                      # Example env variables
├── next.config.ts                    # Next.js config
├── tsconfig.json                     # TypeScript config
├── tailwind.config.ts                # Tailwind config
├── package.json
├── README.md
└── DATABASE_SCHEMA.sql               # Complete Supabase schema
```

## Key Architecture Decisions

### Frontend Structure
- **Next.js 15 App Router** - Server components by default, client components where needed
- **TypeScript** - Strict mode for type safety
- **Tailwind + ShadCN** - Component library built on Tailwind
- **Framer Motion** - Smooth animations and transitions
- **Lucide Icons** - Modern icon library

### Backend Structure
- **API Routes** - Next.js API routes for backend logic
- **Server Actions** - For safe mutations and DB operations
- **Middleware** - Authentication and rate limiting

### Database
- **Supabase** - PostgreSQL + Auth + Real-time
- **Row Level Security** - User data isolation
- **Triggers** - Auto-update timestamps, calculate XP

### Authentication
- **Supabase Auth** - Email/password + Google OAuth
- **JWT Tokens** - Secure session management
- **Protected Routes** - Middleware for route protection

### AI Integration
- **OpenAI API** - GPT-4 for intelligent responses
- **Streaming** - Real-time response streaming
- **Context Memory** - Conversation history management
- **Rate Limiting** - Prevent abuse

### State Management
- **React Context** - User auth state
- **Custom Hooks** - Data fetching and caching
- **SWR/Tanstack Query** - Optional for advanced caching

### Performance
- **Code Splitting** - Dynamic imports for routes
- **Image Optimization** - Next.js Image component
- **Caching** - Server-side and client-side caching
- **CDN** - Vercel's global CDN

---

This structure ensures:
✅ **Scalability** - Easy to add new features
✅ **Maintainability** - Clear separation of concerns
✅ **Performance** - Optimized loading and rendering
✅ **Security** - Protected routes and secure API calls
✅ **Developer Experience** - Clean, organized code
