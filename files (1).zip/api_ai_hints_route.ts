// app/api/ai/hints/route.ts
// Hint Generator API

import { NextRequest, NextResponse } from 'next/server';
import { openai } from '@/lib/clients';
import { supabase } from '@/lib/clients';
import { getHintPrompt } from '@/lib/ai-prompts';
import { HintGeneratorRequest, HintGeneratorResponse } from '@/lib/types';
import { verifyAuth } from '@/lib/auth';
import { rateLimitCheck } from '@/lib/rate-limit';

/**
 * POST /api/ai/hints
 * Generate hints for a problem
 */
export async function POST(request: NextRequest) {
  try {
    // 1. Verify authentication
    const user = await verifyAuth(request);
    if (!user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // 2. Rate limiting
    const rateLimitResult = await rateLimitCheck(user.id, 'hint_generator');
    if (!rateLimitResult.allowed) {
      return NextResponse.json(
        { error: 'Rate limit exceeded' },
        { status: 429 }
      );
    }

    // 3. Parse request
    const body: HintGeneratorRequest = await request.json();
    const { problem_id, hint_level = 1 } = body;

    if (!problem_id || ![1, 2, 3, 4].includes(hint_level)) {
      return NextResponse.json(
        { error: 'Invalid request parameters' },
        { status: 400 }
      );
    }

    // 4. Fetch problem from database
    const { data: problem, error: problemError } = await supabase
      .from('problems')
      .select('*')
      .eq('id', problem_id)
      .single();

    if (problemError || !problem) {
      return NextResponse.json(
        { error: 'Problem not found' },
        { status: 404 }
      );
    }

    // 5. Check if hint already exists in database
    const { data: existingHint } = await supabase
      .from('hints')
      .select('*')
      .eq('user_id', user.id)
      .eq('problem_id', problem_id)
      .eq('hint_level', hint_level)
      .single();

    if (existingHint) {
      return NextResponse.json({
        hint: existingHint.hint_text,
        hint_level: hint_level,
        next_level_hint_available: hint_level < 4,
      } as HintGeneratorResponse);
    }

    // 6. Generate hint using OpenAI
    const prompt = getHintPrompt(hint_level as 1 | 2 | 3 | 4, problem.description);

    const response = await openai.chat.completions.create({
      model: process.env.NEXT_PUBLIC_OPENAI_MODEL || 'gpt-4-turbo',
      messages: [
        {
          role: 'system',
          content: 'You are a helpful coding mentor. Provide hints at the requested level without giving away the solution.',
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      temperature: 0.7,
      max_tokens: 500,
    });

    const hintText = response.choices[0]?.message?.content || '';

    // 7. Save hint to database
    await supabase
      .from('hints')
      .insert({
        user_id: user.id,
        problem_id: problem_id,
        hint_level: hint_level,
        hint_text: hintText,
        revealed_at: new Date().toISOString(),
      });

    // 8. Award XP for using hints
    await supabase.rpc('award_xp', {
      user_id: user.id,
      xp_amount: 10,
      activity_description: `hint_level_${hint_level}_used`,
    });

    // 9. Log activity
    await supabase
      .from('activity_log')
      .insert({
        user_id: user.id,
        activity_type: 'hint_used',
        problem_id: problem_id,
        xp_earned: 10,
      });

    return NextResponse.json({
      hint: hintText,
      hint_level: hint_level,
      next_level_hint_available: hint_level < 4,
    } as HintGeneratorResponse);
  } catch (error) {
    console.error('Hint generator error:', error);
    return NextResponse.json(
      { error: 'Failed to generate hint' },
      { status: 500 }
    );
  }
}

/**
 * GET /api/ai/hints?problem_id=xxx&user_id=xxx
 * Get all hints for a problem
 */
export async function GET(request: NextRequest) {
  try {
    const user = await verifyAuth(request);
    if (!user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const problemId = searchParams.get('problem_id');

    if (!problemId) {
      return NextResponse.json(
        { error: 'problem_id is required' },
        { status: 400 }
      );
    }

    // Fetch all hints for this problem
    const { data: hints, error } = await supabase
      .from('hints')
      .select('*')
      .eq('user_id', user.id)
      .eq('problem_id', problemId)
      .order('hint_level', { ascending: true });

    if (error) {
      throw error;
    }

    return NextResponse.json({
      hints: hints || [],
      count: hints?.length || 0,
    });
  } catch (error) {
    console.error('Get hints error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch hints' },
      { status: 500 }
    );
  }
}
