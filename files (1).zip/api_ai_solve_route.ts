// app/api/ai/solve/route.ts
// Problem Solver API with OpenAI streaming

import { NextRequest, NextResponse } from 'next/server';
import { openai } from '@/lib/clients';
import { getProblemSolverPrompt } from '@/lib/ai-prompts';
import { ProblemSolverRequest, ProblemSolverResponse } from '@/lib/types';
import { rateLimitCheck } from '@/lib/rate-limit';
import { verifyAuth } from '@/lib/auth';

/**
 * POST /api/ai/solve
 * Generate problem solutions using AI
 */
export async function POST(request: NextRequest) {
  try {
    // 1. Verify authentication
    const user = await verifyAuth(request);
    if (!user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // 2. Rate limiting
    const rateLimitResult = await rateLimitCheck(user.id, 'problem_solver');
    if (!rateLimitResult.allowed) {
      return NextResponse.json(
        { error: 'Rate limit exceeded. Try again later.' },
        { status: 429 }
      );
    }

    // 3. Parse request body
    const body: ProblemSolverRequest = await request.json();
    const { problem, language = 'python' } = body;

    if (!problem || problem.trim().length === 0) {
      return NextResponse.json(
        { error: 'Problem statement is required' },
        { status: 400 }
      );
    }

    // 4. Generate prompt
    const prompt = getProblemSolverPrompt(problem, language);

    // 5. Call OpenAI API with streaming
    const stream = await openai.chat.completions.create({
      model: process.env.NEXT_PUBLIC_OPENAI_MODEL || 'gpt-4-turbo',
      messages: [
        {
          role: 'system',
          content: 'You are an expert software engineer. Provide detailed problem explanations and solutions.',
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      temperature: 0.7,
      max_tokens: 2000,
      stream: true,
    });

    // 6. Create a readable stream for the response
    const readable = new ReadableStream({
      async start(controller) {
        try {
          for await (const chunk of stream) {
            const content = chunk.choices[0]?.delta?.content;
            if (content) {
              controller.enqueue(new TextEncoder().encode(content));
            }
          }
          controller.close();
        } catch (error) {
          controller.error(error);
        }
      },
    });

    // 7. Return streaming response
    return new NextResponse(readable, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });
  } catch (error) {
    console.error('Problem solver error:', error);
    return NextResponse.json(
      { error: 'Failed to generate solution' },
      { status: 500 }
    );
  }
}

/**
 * GET /api/ai/solve
 * Health check endpoint
 */
export async function GET() {
  return NextResponse.json({
    status: 'ok',
    message: 'Problem solver endpoint is running',
  });
}
