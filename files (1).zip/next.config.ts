// next.config.ts
import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  // Optimize images
  images: {
    formats: ['image/avif', 'image/webp'],
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**.supabase.co',
      },
      {
        protocol: 'https',
        hostname: '**.githubusercontent.com',
      },
    ],
    minimumCacheTTL: 60 * 60 * 24 * 365, // 1 year
  },

  // Optimize fonts
  fonts: {
    families: [
      {
        name: 'Inter',
        path: './public/fonts/inter',
        style: 'normal',
      },
    ],
  },

  // Compression
  compress: true,

  // Enable React strict mode in development
  reactStrictMode: true,

  // SWR configuration
  swr: {
    strategy: 'revalidate',
  },

  // Environment variables
  env: {
    NEXT_PUBLIC_APP_NAME: 'LeetCode AI Mentor',
    NEXT_PUBLIC_APP_DESCRIPTION: 'Master DSA with AI-powered learning',
  },

  // Headers for security
  headers: async () => {
    return [
      {
        source: '/:path*',
        headers: [
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-XSS-Protection',
            value: '1; mode=block',
          },
          {
            key: 'Referrer-Policy',
            value: 'strict-origin-when-cross-origin',
          },
          {
            key: 'Permissions-Policy',
            value: 'camera=(), microphone=(), geolocation=()',
          },
        ],
      },
    ];
  },

  // Redirects
  redirects: async () => {
    return [
      {
        source: '/docs',
        destination: 'https://docs.leetcode-ai-mentor.com',
        permanent: true,
      },
    ];
  },

  // Rewrites
  rewrites: async () => {
    return {
      beforeFiles: [],
      afterFiles: [],
      fallback: [],
    };
  },

  // Webpack optimization
  webpack: (config, { isServer }) => {
    if (!isServer) {
      config.optimization.splitChunks.cacheGroups = {
        ...config.optimization.splitChunks.cacheGroups,
        // Optimize vendor split
        vendor: {
          test: /[\\/]node_modules[\\/]/,
          name: 'vendors',
          priority: 10,
          reuseExistingChunk: true,
        },
        // Separate common modules
        common: {
          minChunks: 2,
          priority: 5,
          reuseExistingChunk: true,
        },
      };
    }

    return config;
  },

  // Experimental features (optional)
  experimental: {
    // Optimize package imports
    optimizePackageImports: [
      '@ui/components',
      '@icons/react',
    ],
    // Enable React Server Components (default in Next.js 13+)
    esmExternals: 'loose',
  },

  // Custom server settings
  serverRuntimeConfig: {
    PROJECT_ROOT: __dirname,
  },

  // Skip validation on static exports
  staticValidation: {
    dynamicRoutes: true,
  },

  // Trailing slash configuration
  trailingSlash: false,

  // Output configuration
  output: 'standalone',

  // Increase body size limit for file uploads
  api: {
    bodyParser: {
      sizeLimit: '50mb',
    },
  },

  // Optimize build
  swcMinify: true,

  // Generate ETags
  generateEtags: true,

  // PoweredByHeader
  poweredByHeader: false,

  // Production source maps (optional - disable for smaller bundles)
  productionBrowserSourceMaps: false,
};

export default nextConfig;
