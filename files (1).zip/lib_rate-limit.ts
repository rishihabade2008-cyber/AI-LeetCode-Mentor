// lib/rate-limit.ts
// Rate limiting for API endpoints

import { supabase } from '@/lib/clients';

interface RateLimitConfig {
  window_ms: number; // Time window in milliseconds
  max_requests: number; // Max requests per window
}

const RATE_LIMIT_CONFIGS: Record<string, RateLimitConfig> = {
  problem_solver: {
    window_ms: 60 * 1000, // 1 minute
    max_requests: 10,
  },
  hint_generator: {
    window_ms: 60 * 1000, // 1 minute
    max_requests: 20,
  },
  code_analyzer: {
    window_ms: 60 * 1000, // 1 minute
    max_requests: 15,
  },
  interview_question: {
    window_ms: 60 * 1000, // 1 minute
    max_requests: 5,
  },
  default: {
    window_ms: 60 * 1000, // 1 minute
    max_requests: 100,
  },
};

/**
 * Check if user has exceeded rate limit
 */
export async function rateLimitCheck(
  userId: string,
  endpoint: string
): Promise<{ allowed: boolean; remaining: number; resetAt: number }> {
  try {
    const config = RATE_LIMIT_CONFIGS[endpoint] || RATE_LIMIT_CONFIGS.default;
    const now = Date.now();
    const windowStart = now - config.window_ms;

    // Fetch recent activities
    const { data: activities } = await supabase
      .from('activity_log')
      .select('created_at')
      .eq('user_id', userId)
      .gte('created_at', new Date(windowStart).toISOString())
      .order('created_at', { ascending: false });

    const requestCount = activities?.length || 0;
    const allowed = requestCount < config.max_requests;
    const remaining = Math.max(0, config.max_requests - requestCount - 1);
    const resetAt = windowStart + config.window_ms;

    return {
      allowed,
      remaining,
      resetAt,
    };
  } catch (error) {
    console.error('Rate limit check error:', error);
    // Allow request on error (fail open)
    return {
      allowed: true,
      remaining: 0,
      resetAt: Date.now(),
    };
  }
}

/**
 * Record API call for rate limiting
 */
export async function recordAPICall(userId: string, endpoint: string) {
  try {
    await supabase
      .from('activity_log')
      .insert({
        user_id: userId,
        activity_type: 'api_call',
      });
  } catch (error) {
    console.error('Record API call error:', error);
  }
}

/**
 * Get rate limit status for user
 */
export async function getRateLimitStatus(userId: string) {
  const status: Record<string, any> = {};

  for (const [endpoint, config] of Object.entries(RATE_LIMIT_CONFIGS)) {
    const result = await rateLimitCheck(userId, endpoint);
    status[endpoint] = {
      allowed: result.allowed,
      remaining: result.remaining,
      max_requests: config.max_requests,
      window_ms: config.window_ms,
      reset_at: new Date(result.resetAt).toISOString(),
    };
  }

  return status;
}

/**
 * Reset rate limit for user (admin only)
 */
export async function resetUserRateLimit(userId: string) {
  try {
    // Delete activity logs from current window
    const windowStart = new Date(Date.now() - 60 * 60 * 1000); // Last hour

    const { error } = await supabase
      .from('activity_log')
      .delete()
      .eq('user_id', userId)
      .gte('created_at', windowStart.toISOString());

    if (error) throw error;

    return { success: true };
  } catch (error) {
    console.error('Reset rate limit error:', error);
    return { success: false, error };
  }
}
