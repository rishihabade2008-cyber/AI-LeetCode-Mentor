// lib/ai-prompts.ts
// Template prompts for AI interactions

export const AI_PROMPTS = {
  // ============================================
  // PROBLEM SOLVER PROMPTS
  // ============================================
  PROBLEM_SOLVER: `You are an expert software engineer and competitive programmer. 
A user has provided a coding problem. Your task is to:

1. Provide a clear explanation of the problem
2. Provide a brute-force solution with explanation
3. Provide an optimized solution with explanation
4. Analyze time and space complexity for both solutions
5. Provide a dry run with example inputs/outputs
6. List potential edge cases

Format your response as JSON with the following structure:
{
  "problem_explanation": "Clear explanation of what the problem is asking",
  "brute_force_solution": "Code for brute force approach",
  "brute_force_explanation": "Explanation of brute force approach",
  "optimized_solution": "Code for optimized approach",
  "optimized_explanation": "Explanation of optimized approach",
  "time_complexity": "Big-O time complexity analysis",
  "space_complexity": "Big-O space complexity analysis",
  "dry_run": "Step-by-step execution with example input",
  "edge_cases": ["edge case 1", "edge case 2", "edge case 3"]
}

Problem:
`,

  // ============================================
  // HINT GENERATOR PROMPTS
  // ============================================
  HINT_LEVEL_1: `You are a helpful coding mentor. A user is stuck on a problem and needs a small clue.
Provide a very brief hint (1-2 sentences) that points them in the right direction without giving away the solution.
Focus on the key insight they need to understand.

Problem: {problem}
Current hint level: 1/4`,

  HINT_LEVEL_2: `You are a helpful coding mentor. A user needs a hint about the approach to solve this problem.
Explain the high-level approach or strategy they should use (2-3 sentences).
Describe the algorithm or technique without providing code.

Problem: {problem}
Current hint level: 2/4`,

  HINT_LEVEL_3: `You are a helpful coding mentor. A user needs a detailed hint about how to solve this problem.
Explain the algorithm in detail with pseudocode or step-by-step instructions (3-5 sentences).
Include data structures they should use and key algorithmic steps.

Problem: {problem}
Current hint level: 3/4`,

  HINT_LEVEL_4: `You are a helpful coding mentor. A user is very stuck and needs almost the complete solution.
Provide skeleton code or a nearly complete implementation with explanations.
Include comments explaining each major step.

Problem: {problem}
Current hint level: 4/4`,

  // ============================================
  // CODE ANALYZER PROMPTS
  // ============================================
  CODE_ANALYZER: `You are an expert code reviewer. Analyze the following code and provide detailed feedback.

Code to analyze:
\`\`\`
{code}
\`\`\`

Language: {language}
Problem context: {problem_context}

Analyze and provide feedback in JSON format:
{
  "bugs": [
    {
      "line": 5,
      "severity": "critical",
      "message": "Bug description",
      "suggestion": "How to fix it"
    }
  ],
  "syntax_issues": [...],
  "logic_issues": [...],
  "optimizations": [
    {
      "current": "Current code snippet",
      "optimized": "Optimized code snippet",
      "improvement": "What improves (speed, memory, etc)",
      "explanation": "Why this is better"
    }
  ],
  "better_algorithms": [
    {
      "current_algorithm": "Current approach name",
      "suggested_algorithm": "Better approach name",
      "benefit": "Why it's better",
      "time_complexity_current": "O(n²)",
      "time_complexity_suggested": "O(n log n)",
      "implementation_difficulty": "medium"
    }
  ],
  "overall_feedback": "Summary of the code quality and main recommendations"
}`,

  // ============================================
  // INTERVIEW QUESTION GENERATOR
  // ============================================
  INTERVIEW_DSA: `Generate a challenging DSA interview question for a {difficulty} level interview.
Topic (optional): {topic}

Format as JSON:
{
  "question": "The interview question",
  "follow_up_questions": [
    "What if constraint X changes?",
    "Can you do this in O(n) time?"
  ],
  "hints": [
    "First hint",
    "Second hint"
  ]
}`,

  INTERVIEW_SYSTEM_DESIGN: `Generate a system design interview question.

Format as JSON:
{
  "question": "The system design question",
  "follow_up_questions": [
    "How would you handle scaling?",
    "What about failure recovery?"
  ],
  "hints": [
    "Consider the CAP theorem",
    "Think about load balancing"
  ]
}`,

  INTERVIEW_BEHAVIORAL: `Generate a behavioral interview question.

Format as JSON:
{
  "question": "The behavioral question",
  "follow_up_questions": [
    "What was the outcome?",
    "What did you learn?"
  ],
  "hints": [
    "Focus on the action you took",
    "Emphasize the impact"
  ]
}`,

  // ============================================
  // INTERVIEW FEEDBACK PROMPT
  // ============================================
  INTERVIEW_FEEDBACK: `You are an expert technical interviewer. Evaluate the candidate's response.

Question: {question}
Candidate's Answer: {answer}
Question Type: {question_type}

Provide constructive feedback in JSON format:
{
  "rating": 3.5,
  "strengths": ["What they did well"],
  "areas_for_improvement": ["What they could improve"],
  "specific_feedback": "Detailed feedback on their answer",
  "follow_up_questions": ["Questions to dig deeper"],
  "overall_assessment": "Brief overall assessment"
}

Rate on a scale of 1-5, where:
1 = Incomplete/No understanding
2 = Below expectations
3 = Meets expectations
4 = Exceeds expectations
5 = Outstanding`,

  // ============================================
  // LEARNING ROADMAP GENERATOR
  // ============================================
  LEARNING_ROADMAP: `You are an expert DSA instructor. Create a personalized learning roadmap for a {skill_level} developer.

Generate a structured learning path in JSON format:
{
  "total_weeks": 12,
  "roadmap": [
    {
      "week": 1,
      "topics": ["Arrays", "Basic Array Operations"],
      "estimated_hours": 8,
      "problems": 15,
      "description": "Foundation in arrays"
    }
  ],
  "weekly_goals": "Practice 3-5 problems daily",
  "resources": ["LeetCode", "GeeksforGeeks"],
  "milestones": ["Complete Arrays", "Start Linked Lists"]
}`,

  // ============================================
  // SOLUTION GENERATION IN MULTIPLE LANGUAGES
  // ============================================
  MULTI_LANGUAGE_SOLUTION: `Provide the solution to this problem in {language} language.

Problem: {problem}

Requirements:
1. Write clean, production-ready code
2. Include comments explaining the approach
3. Use appropriate data structures
4. Follow {language} best practices
5. Handle edge cases

Return only the code without explanation.`,
};

// ============================================
// PROMPT HELPER FUNCTIONS
// ============================================

/**
 * Replace template variables in prompts
 */
export function interpolatePrompt(
  prompt: string,
  variables: Record<string, string | number>
): string {
  let result = prompt;
  Object.entries(variables).forEach(([key, value]) => {
    result = result.replace(new RegExp(`{${key}}`, 'g'), String(value));
  });
  return result;
}

/**
 * Get problem solver prompt
 */
export function getProblemSolverPrompt(problem: string, language: string): string {
  return AI_PROMPTS.PROBLEM_SOLVER + `\nLanguage requested: ${language}\n\n${problem}`;
}

/**
 * Get hint prompt for specific level
 */
export function getHintPrompt(
  hintLevel: 1 | 2 | 3 | 4,
  problem: string
): string {
  const promptKey = `HINT_LEVEL_${hintLevel}` as keyof typeof AI_PROMPTS;
  return interpolatePrompt(AI_PROMPTS[promptKey] as string, { problem });
}

/**
 * Get code analyzer prompt
 */
export function getCodeAnalyzerPrompt(
  code: string,
  language: string,
  problemContext?: string
): string {
  return interpolatePrompt(AI_PROMPTS.CODE_ANALYZER, {
    code,
    language,
    problem_context: problemContext || 'No specific problem context',
  });
}

/**
 * Get interview question prompt
 */
export function getInterviewQuestionPrompt(
  type: 'dsa' | 'system_design' | 'behavioral',
  difficulty?: string,
  topic?: string
): string {
  const promptKey = `INTERVIEW_${type.toUpperCase()}` as keyof typeof AI_PROMPTS;
  return interpolatePrompt(AI_PROMPTS[promptKey] as string, {
    difficulty: difficulty || 'medium',
    topic: topic || 'General',
  });
}

/**
 * Get interview feedback prompt
 */
export function getInterviewFeedbackPrompt(
  question: string,
  answer: string,
  questionType: string
): string {
  return interpolatePrompt(AI_PROMPTS.INTERVIEW_FEEDBACK, {
    question,
    answer,
    question_type: questionType,
  });
}

/**
 * Get learning roadmap prompt
 */
export function getLearningRoadmapPrompt(skillLevel: string): string {
  return interpolatePrompt(AI_PROMPTS.LEARNING_ROADMAP, {
    skill_level: skillLevel,
  });
}

/**
 * Get multi-language solution prompt
 */
export function getMultiLanguageSolutionPrompt(
  problem: string,
  language: string
): string {
  return interpolatePrompt(AI_PROMPTS.MULTI_LANGUAGE_SOLUTION, {
    problem,
    language,
  });
}
