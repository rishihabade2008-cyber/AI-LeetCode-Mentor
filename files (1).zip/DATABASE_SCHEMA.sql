-- LeetCode AI Mentor - Complete Database Schema
-- Deploy this in Supabase SQL Editor

-- ============================================
-- 1. USERS TABLE (Extended Profile)
-- ============================================
CREATE TABLE users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  name TEXT,
  avatar_url TEXT,
  bio TEXT,
  profession TEXT,
  experience_level VARCHAR(20) DEFAULT 'beginner', -- beginner, intermediate, advanced
  preferred_language VARCHAR(20) DEFAULT 'python', -- python, java, cpp, javascript, typescript, go
  dark_mode BOOLEAN DEFAULT true,
  xp INT DEFAULT 0,
  level INT DEFAULT 1,
  streak INT DEFAULT 0,
  last_activity_date TIMESTAMP DEFAULT NOW(),
  total_study_time INT DEFAULT 0, -- in minutes
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- 2. PROBLEMS TABLE
-- ============================================
CREATE TABLE problems (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  difficulty VARCHAR(20) NOT NULL CHECK (difficulty IN ('easy', 'medium', 'hard')),
  topic VARCHAR(50) NOT NULL, -- arrays, strings, trees, graphs, dp, etc
  tags TEXT[] DEFAULT ARRAY[]::TEXT[],
  problem_source TEXT, -- leetcode, codeforces, custom, etc
  problem_url TEXT,
  image_url TEXT,
  is_custom BOOLEAN DEFAULT false,
  is_favorite BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- 3. SOLUTIONS TABLE
-- ============================================
CREATE TABLE solutions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  problem_id UUID NOT NULL REFERENCES problems(id) ON DELETE CASCADE,
  language VARCHAR(20) NOT NULL, -- python, java, cpp, javascript, typescript, go
  code TEXT NOT NULL,
  explanation TEXT,
  time_complexity VARCHAR(100),
  space_complexity VARCHAR(100),
  approach TEXT, -- brute-force, optimized, etc
  is_correct BOOLEAN DEFAULT false,
  rating INT, -- 1-5 star rating
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, problem_id, language)
);

-- ============================================
-- 4. AI EXPLANATIONS TABLE
-- ============================================
CREATE TABLE ai_explanations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  problem_id UUID NOT NULL REFERENCES problems(id) ON DELETE CASCADE,
  explanation_type VARCHAR(50) NOT NULL, -- problem, solution, hint, analysis, etc
  content TEXT NOT NULL,
  language VARCHAR(20), -- if applicable
  helpful_count INT DEFAULT 0,
  unhelpful_count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- 5. HINTS TABLE
-- ============================================
CREATE TABLE hints (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  problem_id UUID NOT NULL REFERENCES problems(id) ON DELETE CASCADE,
  hint_level INT NOT NULL CHECK (hint_level BETWEEN 1 AND 4),
  hint_text TEXT NOT NULL,
  -- Level 1: Small clue
  -- Level 2: Approach explanation
  -- Level 3: Detailed algorithm hint
  -- Level 4: Almost complete solution
  revealed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- 6. BOOKMARKS TABLE
-- ============================================
CREATE TABLE bookmarks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  problem_id UUID REFERENCES problems(id) ON DELETE CASCADE,
  solution_id UUID REFERENCES solutions(id) ON DELETE CASCADE,
  bookmark_type VARCHAR(20) NOT NULL CHECK (bookmark_type IN ('problem', 'solution', 'explanation')),
  folder_id UUID,
  notes TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, problem_id, solution_id, bookmark_type)
);

-- ============================================
-- 7. BOOKMARK FOLDERS TABLE
-- ============================================
CREATE TABLE bookmark_folders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  folder_name TEXT NOT NULL,
  description TEXT,
  color VARCHAR(7) DEFAULT '#6366f1', -- hex color
  icon VARCHAR(50), -- emoji or icon name
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, folder_name)
);

-- ============================================
-- 8. PROGRESS TRACKING TABLE
-- ============================================
CREATE TABLE progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  topic VARCHAR(50) NOT NULL,
  problems_solved INT DEFAULT 0,
  problems_total INT DEFAULT 50, -- estimated total
  completion_percentage INT DEFAULT 0,
  easy_solved INT DEFAULT 0,
  medium_solved INT DEFAULT 0,
  hard_solved INT DEFAULT 0,
  last_updated TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, topic)
);

-- ============================================
-- 9. ACHIEVEMENTS / BADGES TABLE
-- ============================================
CREATE TABLE achievements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  badge_name VARCHAR(100) NOT NULL,
  badge_description TEXT,
  badge_icon TEXT, -- emoji
  achievement_type VARCHAR(50) NOT NULL, -- streak, problems_solved, topic_mastery, speedrun, etc
  progress_current INT DEFAULT 0,
  progress_target INT DEFAULT 1,
  unlocked BOOLEAN DEFAULT false,
  unlocked_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, badge_name)
);

-- ============================================
-- 10. DAILY ACTIVITY LOG
-- ============================================
CREATE TABLE activity_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  activity_type VARCHAR(50) NOT NULL, -- problem_solved, hint_used, solution_viewed, etc
  problem_id UUID REFERENCES problems(id) ON DELETE SET NULL,
  duration_minutes INT, -- study time
  xp_earned INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- 11. INTERVIEW QUESTIONS TABLE
-- ============================================
CREATE TABLE interview_questions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  question TEXT NOT NULL,
  question_type VARCHAR(50) NOT NULL, -- dsa, system_design, behavioral
  topic VARCHAR(50),
  difficulty VARCHAR(20),
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- 12. INTERVIEW RESPONSES TABLE
-- ============================================
CREATE TABLE interview_responses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  question_id UUID NOT NULL REFERENCES interview_questions(id) ON DELETE CASCADE,
  answer TEXT NOT NULL,
  ai_feedback TEXT,
  rating INT, -- 1-5
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- 13. LEARNING ROADMAP TABLE
-- ============================================
CREATE TABLE learning_roadmaps (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  skill_level VARCHAR(20) NOT NULL, -- beginner, intermediate, advanced
  topics TEXT[] NOT NULL, -- array of topics in order
  current_topic VARCHAR(50),
  progress_percentage INT DEFAULT 0,
  estimated_days INT DEFAULT 90,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id)
);

-- ============================================
-- 14. CODE ANALYSIS HISTORY
-- ============================================
CREATE TABLE code_analysis_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  code_submitted TEXT NOT NULL,
  language VARCHAR(20) NOT NULL,
  analysis_result JSONB, -- { bugs: [], optimizations: [], suggestions: [] }
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- 15. LEADERBOARD / RANKINGS
-- ============================================
CREATE TABLE leaderboard (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  rank INT,
  xp_total INT DEFAULT 0,
  problems_solved INT DEFAULT 0,
  streak_current INT DEFAULT 0,
  last_updated TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- INDEXES FOR PERFORMANCE
-- ============================================
CREATE INDEX idx_problems_user_id ON problems(user_id);
CREATE INDEX idx_problems_topic ON problems(topic);
CREATE INDEX idx_problems_difficulty ON problems(difficulty);
CREATE INDEX idx_solutions_user_id ON solutions(user_id);
CREATE INDEX idx_solutions_problem_id ON solutions(problem_id);
CREATE INDEX idx_hints_user_id ON hints(user_id);
CREATE INDEX idx_hints_problem_id ON hints(problem_id);
CREATE INDEX idx_bookmarks_user_id ON bookmarks(user_id);
CREATE INDEX idx_progress_user_id ON progress(user_id);
CREATE INDEX idx_achievements_user_id ON achievements(user_id);
CREATE INDEX idx_activity_log_user_id ON activity_log(user_id);
CREATE INDEX idx_activity_log_created_at ON activity_log(created_at);
CREATE INDEX idx_leaderboard_rank ON leaderboard(rank);

-- ============================================
-- ROW LEVEL SECURITY POLICIES
-- ============================================
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE problems ENABLE ROW LEVEL SECURITY;
ALTER TABLE solutions ENABLE ROW LEVEL SECURITY;
ALTER TABLE hints ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookmarks ENABLE ROW LEVEL SECURITY;
ALTER TABLE progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE interview_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE interview_responses ENABLE ROW LEVEL SECURITY;

-- Users can only see their own data
CREATE POLICY "Users can view their own profile"
  ON users FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON users FOR UPDATE
  USING (auth.uid() = id);

-- Problems RLS
CREATE POLICY "Users can view all public problems"
  ON problems FOR SELECT
  USING (user_id = auth.uid() OR NOT is_custom);

CREATE POLICY "Users can insert their own problems"
  ON problems FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Solutions RLS
CREATE POLICY "Users can view their own solutions"
  ON solutions FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own solutions"
  ON solutions FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Hints RLS
CREATE POLICY "Users can view their own hints"
  ON hints FOR SELECT
  USING (auth.uid() = user_id);

-- Bookmarks RLS
CREATE POLICY "Users can manage their own bookmarks"
  ON bookmarks FOR ALL
  USING (auth.uid() = user_id);

-- Progress RLS
CREATE POLICY "Users can view their own progress"
  ON progress FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert/update their own progress"
  ON progress FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own progress"
  ON progress FOR UPDATE
  USING (auth.uid() = user_id);

-- Achievements RLS
CREATE POLICY "Users can view their own achievements"
  ON achievements FOR SELECT
  USING (auth.uid() = user_id);

-- Activity Log RLS
CREATE POLICY "Users can view their own activity"
  ON activity_log FOR SELECT
  USING (auth.uid() = user_id);

-- ============================================
-- TRIGGERS FOR AUTO-UPDATING TIMESTAMPS
-- ============================================
CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_users_timestamp
BEFORE UPDATE ON users
FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER update_problems_timestamp
BEFORE UPDATE ON problems
FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER update_solutions_timestamp
BEFORE UPDATE ON solutions
FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER update_learning_roadmaps_timestamp
BEFORE UPDATE ON learning_roadmaps
FOR EACH ROW EXECUTE FUNCTION update_timestamp();

-- ============================================
-- FUNCTION TO CALCULATE LEADERBOARD RANKINGS
-- ============================================
CREATE OR REPLACE FUNCTION update_leaderboard()
RETURNS void AS $$
BEGIN
  DELETE FROM leaderboard;
  
  INSERT INTO leaderboard (user_id, xp_total, problems_solved, rank)
  SELECT 
    users.id,
    users.xp,
    COUNT(DISTINCT solutions.problem_id),
    ROW_NUMBER() OVER (ORDER BY users.xp DESC) as rank
  FROM users
  LEFT JOIN solutions ON users.id = solutions.user_id
  GROUP BY users.id, users.xp
  ORDER BY users.xp DESC;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- FUNCTION TO AWARD XP FOR ACTIVITIES
-- ============================================
CREATE OR REPLACE FUNCTION award_xp(
  user_id UUID,
  xp_amount INT,
  activity_description TEXT
)
RETURNS void AS $$
BEGIN
  UPDATE users 
  SET xp = xp + xp_amount,
      last_activity_date = NOW()
  WHERE id = user_id;
  
  INSERT INTO activity_log (user_id, activity_type, xp_earned)
  VALUES (user_id, activity_description, xp_amount);
  
  -- Update level (every 1000 XP)
  UPDATE users 
  SET level = (xp / 1000) + 1
  WHERE id = user_id;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- SAMPLE DATA (Optional - for testing)
-- ============================================
-- Insert sample topics
INSERT INTO progress (user_id, topic, problems_total) VALUES
  ('00000000-0000-0000-0000-000000000001'::UUID, 'Arrays', 50),
  ('00000000-0000-0000-0000-000000000001'::UUID, 'Strings', 40),
  ('00000000-0000-0000-0000-000000000001'::UUID, 'Trees', 60),
  ('00000000-0000-0000-0000-000000000001'::UUID, 'Graphs', 70)
ON CONFLICT DO NOTHING;
