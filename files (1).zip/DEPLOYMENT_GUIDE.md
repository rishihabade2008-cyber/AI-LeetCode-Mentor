# DEPLOYMENT GUIDE - LeetCode AI Mentor

## Prerequisites

- Node.js 18+ and npm/yarn
- Supabase account
- OpenAI API key
- Vercel account (for hosting)
- GitHub account (for version control)

---

## Step 1: Local Development Setup

### 1.1 Clone and Install
```bash
git clone https://github.com/yourusername/leetcode-ai-mentor.git
cd leetcode-ai-mentor
npm install
```

### 1.2 Setup Environment Variables
Create `.env.local` file:
```bash
cp .env.example .env.local
```

Fill in the following:

#### Supabase Setup
1. Go to [supabase.com](https://supabase.com)
2. Create a new project
3. Copy these values to `.env.local`:
   - `NEXT_PUBLIC_SUPABASE_URL` - Project URL
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` - Anon public key
   - `SUPABASE_SERVICE_ROLE_KEY` - Service role key (keep secret)

#### OpenAI Setup
1. Go to [platform.openai.com](https://platform.openai.com)
2. Create API key
3. Add to `.env.local`:
   - `OPENAI_API_KEY` - Your API key

#### Google OAuth (Optional)
1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create OAuth 2.0 credentials
3. Add to `.env.local`:
   - `NEXT_PUBLIC_GOOGLE_CLIENT_ID`
   - `GOOGLE_CLIENT_SECRET`

### 1.3 Setup Supabase Database
1. In Supabase dashboard, go to SQL Editor
2. Create new query
3. Copy entire contents of `DATABASE_SCHEMA.sql`
4. Run the SQL

### 1.4 Run Development Server
```bash
npm run dev
```

Visit `http://localhost:3000`

---

## Step 2: Configure Authentication

### Supabase Auth Setup
1. In Supabase, go to Authentication → Settings
2. Configure:
   - **Site URL**: `http://localhost:3000` (local) or your production URL
   - **Redirect URLs**: 
     - `http://localhost:3000/auth/callback`
     - `https://yourdomain.com/auth/callback`

3. Enable providers:
   - Email/Password
   - Google OAuth

### Environment Variables for Auth
```env
# Add to .env.local for local development
NEXT_PUBLIC_SUPABASE_JWT_SECRET=your-jwt-secret-from-supabase
```

---

## Step 3: Deploy to Vercel

### 3.1 Push to GitHub
```bash
git add .
git commit -m "Initial commit: LeetCode AI Mentor"
git push origin main
```

### 3.2 Deploy on Vercel
1. Go to [vercel.com](https://vercel.com)
2. Click "New Project"
3. Import your GitHub repository
4. Select project settings

### 3.3 Add Environment Variables in Vercel
In Vercel project settings → Environment Variables, add:

```env
NEXT_PUBLIC_SUPABASE_URL=your_production_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_production_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_production_service_role_key

OPENAI_API_KEY=your_openai_api_key
NEXT_PUBLIC_OPENAI_MODEL=gpt-4-turbo

NEXT_PUBLIC_GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_secret

NEXT_PUBLIC_APP_URL=https://yourdomain.vercel.app

NODE_ENV=production
```

### 3.4 Update Supabase Configuration
In Supabase project settings:
- Add Vercel URL to "Site URL": `https://yourdomain.vercel.app`
- Add Vercel URL to redirect URLs

### 3.5 Deploy
Click "Deploy" button in Vercel. Your app will be live in 2-3 minutes!

---

## Step 4: Custom Domain (Optional)

1. In Vercel → Settings → Domains
2. Add your custom domain
3. Update DNS records according to Vercel's instructions
4. Update Supabase auth URLs with your custom domain

---

## Step 5: Production Checklist

- [ ] Environment variables set in Vercel
- [ ] Database schema deployed to Supabase
- [ ] Auth URLs configured in Supabase
- [ ] OpenAI API key working
- [ ] Google OAuth configured
- [ ] Dark mode toggle working
- [ ] All API routes tested
- [ ] Rate limiting active
- [ ] Monitoring enabled

---

## Environment Variables Reference

### Required for All Environments
```env
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
OPENAI_API_KEY=
```

### Optional
```env
NEXT_PUBLIC_GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
NEXT_PUBLIC_OPENAI_MODEL=gpt-4-turbo
RATE_LIMIT_REQUESTS=100
RATE_LIMIT_WINDOW_MS=60000
AI_STREAMING_ENABLED=true
AI_TEMPERATURE=0.7
AI_MAX_TOKENS=2000
```

---

## Monitoring & Maintenance

### Supabase Monitoring
- Go to Database → Monitoring
- Track query performance
- Monitor storage usage

### OpenAI Usage
- Go to platform.openai.com → Usage
- Monitor API calls and costs
- Set usage alerts

### Vercel Analytics
- Vercel dashboard shows performance metrics
- Track Web Vitals
- Monitor deployment history

---

## Scaling Considerations

### Database
- Enable connection pooling in Supabase
- Optimize indexes for frequent queries
- Archive old activity logs monthly

### API Rate Limiting
- Adjust rate limits based on user tier
- Implement caching for expensive operations
- Use Redis for distributed rate limiting (optional)

### OpenAI Costs
- Implement response caching
- Use GPT-3.5-turbo for less critical requests
- Implement daily usage limits per user

---

## Troubleshooting

### "Unauthorized" errors
- Check `NEXT_PUBLIC_SUPABASE_ANON_KEY` is correct
- Verify RLS policies are properly set
- Clear browser cookies and retry

### OpenAI API errors
- Verify `OPENAI_API_KEY` is valid
- Check API usage limits
- Ensure model name is correct (`gpt-4-turbo`)

### Database connection issues
- Verify `NEXT_PUBLIC_SUPABASE_URL` is correct
- Check network connectivity
- Verify RLS policies allow access

### Authentication issues
- Clear Supabase session
- Verify redirect URLs in Supabase
- Check email confirmation settings

---

## Support

- **Supabase Docs**: https://supabase.com/docs
- **OpenAI Docs**: https://platform.openai.com/docs
- **Vercel Docs**: https://vercel.com/docs
- **Next.js Docs**: https://nextjs.org/docs

---

## Cost Estimation (Monthly)

| Service | Free Tier | Estimated Cost |
|---------|-----------|----------------|
| Supabase | $0 (5GB) | $25-100 |
| OpenAI | - | $20-100 |
| Vercel | $0 | $0-20 |
| **Total** | | **$45-220** |

*Costs vary based on usage. Implement rate limiting and caching to reduce costs.*
