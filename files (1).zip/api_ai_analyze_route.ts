// app/api/ai/analyze/route.ts
// Code Analyzer API

import { NextRequest, NextResponse } from 'next/server';
import { openai } from '@/lib/clients';
import { supabase } from '@/lib/clients';
import { getCodeAnalyzerPrompt } from '@/lib/ai-prompts';
import { CodeAnalyzerRequest, CodeAnalysisResult } from '@/lib/types';
import { verifyAuth } from '@/lib/auth';
import { rateLimitCheck } from '@/lib/rate-limit';

/**
 * POST /api/ai/analyze
 * Analyze code and provide suggestions
 */
export async function POST(request: NextRequest) {
  try {
    // 1. Verify authentication
    const user = await verifyAuth(request);
    if (!user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // 2. Rate limiting
    const rateLimitResult = await rateLimitCheck(user.id, 'code_analyzer');
    if (!rateLimitResult.allowed) {
      return NextResponse.json(
        { error: 'Rate limit exceeded' },
        { status: 429 }
      );
    }

    // 3. Parse request
    const body: CodeAnalyzerRequest = await request.json();
    const { code, language, problem_context } = body;

    if (!code || code.trim().length === 0) {
      return NextResponse.json(
        { error: 'Code is required' },
        { status: 400 }
      );
    }

    // 4. Generate analysis prompt
    const prompt = getCodeAnalyzerPrompt(code, language, problem_context);

    // 5. Call OpenAI API
    const response = await openai.chat.completions.create({
      model: process.env.NEXT_PUBLIC_OPENAI_MODEL || 'gpt-4-turbo',
      messages: [
        {
          role: 'system',
          content: 'You are an expert code reviewer. Provide detailed, actionable feedback on code quality, bugs, and optimizations.',
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      temperature: 0.5,
      max_tokens: 2000,
    });

    const analysisText = response.choices[0]?.message?.content || '';

    // 6. Parse JSON response
    let analysis: CodeAnalysisResult;
    try {
      // Extract JSON from response
      const jsonMatch = analysisText.match(/\{[\s\S]*\}/);
      analysis = jsonMatch ? JSON.parse(jsonMatch[0]) : {
        language,
        bugs: [],
        syntax_issues: [],
        logic_issues: [],
        optimizations: [],
        better_algorithms: [],
        overall_feedback: analysisText,
      };
    } catch (parseError) {
      analysis = {
        language,
        bugs: [],
        syntax_issues: [],
        logic_issues: [],
        optimizations: [],
        better_algorithms: [],
        overall_feedback: analysisText,
      };
    }

    // 7. Save analysis to database
    await supabase
      .from('code_analysis_history')
      .insert({
        user_id: user.id,
        code_submitted: code,
        language: language,
        analysis_result: analysis,
      });

    // 8. Award XP for code analysis
    await supabase.rpc('award_xp', {
      user_id: user.id,
      xp_amount: 15,
      activity_description: 'code_analyzed',
    });

    // 9. Log activity
    await supabase
      .from('activity_log')
      .insert({
        user_id: user.id,
        activity_type: 'code_analyzed',
        xp_earned: 15,
      });

    return NextResponse.json({
      analysis: analysis,
      suggestions: generateSuggestions(analysis),
    });
  } catch (error) {
    console.error('Code analyzer error:', error);
    return NextResponse.json(
      { error: 'Failed to analyze code' },
      { status: 500 }
    );
  }
}

/**
 * GET /api/ai/analyze/history?limit=10
 * Get user's code analysis history
 */
export async function GET(request: NextRequest) {
  try {
    const user = await verifyAuth(request);
    if (!user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const limit = Math.min(parseInt(searchParams.get('limit') || '10'), 50);

    const { data: history, error } = await supabase
      .from('code_analysis_history')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) {
      throw error;
    }

    return NextResponse.json({
      history: history || [],
      count: history?.length || 0,
    });
  } catch (error) {
    console.error('Get analysis history error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch history' },
      { status: 500 }
    );
  }
}

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Generate high-level suggestions from analysis
 */
function generateSuggestions(analysis: CodeAnalysisResult): string[] {
  const suggestions: string[] = [];

  // Add critical bugs
  if (analysis.bugs && analysis.bugs.length > 0) {
    suggestions.push(`Fix ${analysis.bugs.length} bug(s) in your code`);
  }

  // Add optimization opportunities
  if (analysis.optimizations && analysis.optimizations.length > 0) {
    suggestions.push(`Implement ${analysis.optimizations.length} optimization(s) for better performance`);
  }

  // Add algorithm improvements
  if (analysis.better_algorithms && analysis.better_algorithms.length > 0) {
    suggestions.push(`Consider ${analysis.better_algorithms[0].suggested_algorithm} instead of ${analysis.better_algorithms[0].current_algorithm}`);
  }

  // Add overall recommendation
  if (analysis.overall_feedback && analysis.overall_feedback.length > 0) {
    suggestions.push('Review the overall feedback provided');
  }

  return suggestions;
}
