// lib/types.ts
// Complete TypeScript types for LeetCode AI Mentor

// ============================================
// USER TYPES
// ============================================
export interface User {
  id: string;
  email: string;
  name: string | null;
  avatar_url: string | null;
  bio: string | null;
  profession: string | null;
  experience_level: 'beginner' | 'intermediate' | 'advanced';
  preferred_language: Language;
  dark_mode: boolean;
  xp: number;
  level: number;
  streak: number;
  last_activity_date: string;
  total_study_time: number; // in minutes
  created_at: string;
  updated_at: string;
}

export interface UserStats {
  problems_solved: number;
  streak: number;
  total_study_time: number;
  xp: number;
  level: number;
  strong_topics: string[];
  weak_topics: string[];
}

// ============================================
// PROBLEM TYPES
// ============================================
export type Difficulty = 'easy' | 'medium' | 'hard';
export type Topic = 
  | 'arrays'
  | 'strings'
  | 'linked-lists'
  | 'trees'
  | 'graphs'
  | 'dynamic-programming'
  | 'greedy'
  | 'backtracking'
  | 'sorting'
  | 'searching'
  | 'heap'
  | 'stack-queue'
  | 'hash-table'
  | 'math'
  | 'bit-manipulation'
  | 'design'
  | 'custom';

export type Language = 'python' | 'java' | 'cpp' | 'javascript' | 'typescript' | 'go';

export interface Problem {
  id: string;
  user_id: string;
  title: string;
  description: string;
  difficulty: Difficulty;
  topic: Topic;
  tags: string[];
  problem_source: string; // leetcode, codeforces, custom, etc
  problem_url: string | null;
  image_url: string | null;
  is_custom: boolean;
  is_favorite: boolean;
  created_at: string;
  updated_at: string;
}

// ============================================
// SOLUTION TYPES
// ============================================
export interface Solution {
  id: string;
  user_id: string;
  problem_id: string;
  language: Language;
  code: string;
  explanation: string | null;
  time_complexity: string | null;
  space_complexity: string | null;
  approach: string;
  is_correct: boolean;
  rating: number | null;
  created_at: string;
  updated_at: string;
}

export interface SolutionAnalysis {
  time_complexity: string;
  space_complexity: string;
  approach: string;
  explanation: string;
  dry_run: string;
  edge_cases: string[];
}

// ============================================
// AI EXPLANATION TYPES
// ============================================
export interface AIExplanation {
  id: string;
  user_id: string;
  problem_id: string;
  explanation_type: 'problem' | 'solution' | 'hint' | 'analysis' | 'optimization';
  content: string;
  language: Language | null;
  helpful_count: number;
  unhelpful_count: number;
  created_at: string;
}

// ============================================
// HINT TYPES
// ============================================
export interface Hint {
  id: string;
  user_id: string;
  problem_id: string;
  hint_level: 1 | 2 | 3 | 4;
  hint_text: string;
  revealed_at: string | null;
  created_at: string;
}

export const HINT_LEVELS = {
  1: 'Small clue - narrow your thinking',
  2: 'Approach explanation - here is the strategy',
  3: 'Detailed algorithm hint - almost there',
  4: 'Nearly complete solution - implement this',
} as const;

// ============================================
// BOOKMARK TYPES
// ============================================
export interface Bookmark {
  id: string;
  user_id: string;
  problem_id: string | null;
  solution_id: string | null;
  bookmark_type: 'problem' | 'solution' | 'explanation';
  folder_id: string | null;
  notes: string | null;
  created_at: string;
}

export interface BookmarkFolder {
  id: string;
  user_id: string;
  folder_name: string;
  description: string | null;
  color: string;
  icon: string | null;
  created_at: string;
}

// ============================================
// PROGRESS TYPES
// ============================================
export interface TopicProgress {
  id: string;
  user_id: string;
  topic: Topic;
  problems_solved: number;
  problems_total: number;
  completion_percentage: number;
  easy_solved: number;
  medium_solved: number;
  hard_solved: number;
  last_updated: string;
}

export interface ProgressMetrics {
  [topic in Topic]?: TopicProgress;
}

// ============================================
// ACHIEVEMENT TYPES
// ============================================
export interface Achievement {
  id: string;
  user_id: string;
  badge_name: string;
  badge_description: string | null;
  badge_icon: string; // emoji
  achievement_type: 'streak' | 'problems_solved' | 'topic_mastery' | 'speedrun' | 'milestone';
  progress_current: number;
  progress_target: number;
  unlocked: boolean;
  unlocked_at: string | null;
  created_at: string;
}

export const ACHIEVEMENTS = {
  first_problem: {
    name: 'First Steps',
    icon: '🚀',
    description: 'Solve your first problem',
  },
  streak_7: {
    name: '7-Day Streak',
    icon: '🔥',
    description: 'Keep your streak going for 7 days',
  },
  streak_30: {
    name: '30-Day Streak',
    icon: '🏆',
    description: 'Maintain a 30-day coding streak',
  },
  problems_100: {
    name: 'Century',
    icon: '💯',
    description: 'Solve 100 problems',
  },
  problems_250: {
    name: 'Quarter Thousand',
    icon: '🎯',
    description: 'Solve 250 problems',
  },
  topic_mastery: {
    name: 'Master',
    icon: '👑',
    description: 'Complete all problems in a topic',
  },
} as const;

// ============================================
// ACTIVITY LOG TYPES
// ============================================
export type ActivityType = 
  | 'problem_solved'
  | 'hint_used'
  | 'solution_viewed'
  | 'code_analyzed'
  | 'interview_attempted'
  | 'bookmark_created'
  | 'achievement_unlocked';

export interface ActivityLog {
  id: string;
  user_id: string;
  activity_type: ActivityType;
  problem_id: string | null;
  duration_minutes: number | null;
  xp_earned: number;
  created_at: string;
}

// ============================================
// INTERVIEW TYPES
// ============================================
export interface InterviewQuestion {
  id: string;
  user_id: string;
  question: string;
  question_type: 'dsa' | 'system_design' | 'behavioral';
  topic: Topic | null;
  difficulty: Difficulty | null;
  created_at: string;
}

export interface InterviewResponse {
  id: string;
  user_id: string;
  question_id: string;
  answer: string;
  ai_feedback: string | null;
  rating: number | null;
  created_at: string;
}

// ============================================
// LEARNING ROADMAP TYPES
// ============================================
export interface LearningRoadmap {
  id: string;
  user_id: string;
  skill_level: 'beginner' | 'intermediate' | 'advanced';
  topics: Topic[];
  current_topic: Topic | null;
  progress_percentage: number;
  estimated_days: number;
  created_at: string;
  updated_at: string;
}

export const ROADMAP_BEGINNER: Topic[] = [
  'arrays',
  'strings',
  'searching',
  'sorting',
  'hash-table',
];

export const ROADMAP_INTERMEDIATE: Topic[] = [
  'linked-lists',
  'stack-queue',
  'trees',
  'heap',
  'dynamic-programming',
  'graphs',
];

export const ROADMAP_ADVANCED: Topic[] = [
  'advanced-graphs',
  'bit-manipulation',
  'greedy',
  'backtracking',
  'design',
];

// ============================================
// CODE ANALYSIS TYPES
// ============================================
export interface CodeAnalysisResult {
  language: Language;
  bugs: CodeIssue[];
  syntax_issues: CodeIssue[];
  logic_issues: CodeIssue[];
  optimizations: OptimizationSuggestion[];
  better_algorithms: AlgorithmSuggestion[];
  overall_feedback: string;
}

export interface CodeIssue {
  line: number;
  severity: 'critical' | 'warning' | 'info';
  message: string;
  suggestion: string;
}

export interface OptimizationSuggestion {
  current: string;
  optimized: string;
  improvement: string;
  explanation: string;
}

export interface AlgorithmSuggestion {
  current_algorithm: string;
  suggested_algorithm: string;
  benefit: string;
  time_complexity_current: string;
  time_complexity_suggested: string;
  implementation_difficulty: 'easy' | 'medium' | 'hard';
}

// ============================================
// LEADERBOARD TYPES
// ============================================
export interface LeaderboardEntry {
  id: string;
  user_id: string;
  user_name: string;
  user_avatar: string | null;
  rank: number;
  xp_total: number;
  problems_solved: number;
  streak_current: number;
  last_updated: string;
}

// ============================================
// API REQUEST/RESPONSE TYPES
// ============================================
export interface ProblemSolverRequest {
  problem: string;
  problem_image?: string; // base64
  language: Language;
  difficulty?: Difficulty;
}

export interface ProblemSolverResponse {
  problem_explanation: string;
  brute_force_solution: string;
  optimized_solution: string;
  time_complexity: string;
  space_complexity: string;
  dry_run: string;
  edge_cases: string[];
  solutions_by_language: Record<Language, string>;
}

export interface HintGeneratorRequest {
  problem_id: string;
  hint_level: 1 | 2 | 3 | 4;
}

export interface HintGeneratorResponse {
  hint: string;
  hint_level: 1 | 2 | 3 | 4;
  next_level_hint_available: boolean;
}

export interface CodeAnalyzerRequest {
  code: string;
  language: Language;
  problem_context?: string;
}

export interface CodeAnalyzerResponse {
  analysis: CodeAnalysisResult;
  suggestions: string[];
}

export interface InterviewModeRequest {
  question_type: 'dsa' | 'system_design' | 'behavioral';
  topic?: Topic;
  difficulty?: Difficulty;
}

export interface InterviewModeResponse {
  question: string;
  follow_up_questions: string[];
  hints: string[];
}

// ============================================
// UI COMPONENT PROP TYPES
// ============================================
export interface ButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  className?: string;
}

export interface CardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  hover?: boolean;
}

export interface ToastProps {
  message: string;
  type: 'success' | 'error' | 'info' | 'warning';
  duration?: number;
}

// ============================================
// API ERROR TYPES
// ============================================
export interface APIError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
  status_code: number;
}

// ============================================
// FORM SUBMISSION TYPES
// ============================================
export interface FormState {
  isSubmitting: boolean;
  error: string | null;
  success: boolean;
}

// ============================================
// PAGINATION TYPES
// ============================================
export interface PaginationParams {
  page: number;
  limit: number;
  sort?: string;
  order?: 'asc' | 'desc';
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  total_pages: number;
}

// ============================================
// FILTER TYPES
// ============================================
export interface ProblemFilters {
  difficulty?: Difficulty;
  topic?: Topic;
  is_custom?: boolean;
  search?: string;
}

export interface SolutionFilters {
  language?: Language;
  is_correct?: boolean;
  approach?: string;
}

// ============================================
// EXPORT UTILITY TYPE
// ============================================
export type Awaitable<T> = Promise<T> | T;
export type ReactNode = React.ReactNode;
