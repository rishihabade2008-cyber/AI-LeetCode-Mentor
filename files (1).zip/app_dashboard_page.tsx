// app/dashboard/page.tsx
// Main Dashboard Home Page

'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Activity, TrendingUp, Zap, Target, Calendar, Award } from 'lucide-react';
import { supabase } from '@/lib/clients';
import { User, ActivityLog, Achievement, TopicProgress } from '@/lib/types';
import StatsCard from '@/components/dashboard/StatsCard';
import ProgressChart from '@/components/dashboard/ProgressChart';
import ActivityFeed from '@/components/dashboard/ActivityFeed';
import AchievementBadge from '@/components/dashboard/AchievementBadge';

export default function DashboardPage() {
  const [user, setUser] = useState<User | null>(null);
  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [topicProgress, setTopicProgress] = useState<TopicProgress[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  async function loadDashboardData() {
    try {
      // Get current user
      const {
        data: { user: authUser },
      } = await supabase.auth.getUser();

      if (!authUser) return;

      // Fetch user profile
      const { data: userProfile } = await supabase
        .from('users')
        .select('*')
        .eq('id', authUser.id)
        .single();

      setUser(userProfile);

      // Fetch recent activities
      const { data: activityData } = await supabase
        .from('activity_log')
        .select('*')
        .eq('user_id', authUser.id)
        .order('created_at', { ascending: false })
        .limit(10);

      setActivities(activityData || []);

      // Fetch achievements
      const { data: achievementData } = await supabase
        .from('achievements')
        .select('*')
        .eq('user_id', authUser.id)
        .eq('unlocked', true)
        .limit(4);

      setAchievements(achievementData || []);

      // Fetch topic progress
      const { data: progressData } = await supabase
        .from('progress')
        .select('*')
        .eq('user_id', authUser.id)
        .order('completion_percentage', { ascending: false })
        .limit(5);

      setTopicProgress(progressData || []);
    } catch (error) {
      console.error('Error loading dashboard:', error);
    } finally {
      setLoading(false);
    }
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin">
          <div className="w-16 h-16 border-4 border-gray-300 border-t-blue-500 rounded-full"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-850 p-6 md:p-10">
      <motion.div
        initial="hidden"
        animate="visible"
        variants={containerVariants}
        className="max-w-7xl mx-auto space-y-8"
      >
        {/* Header */}
        <motion.div variants={itemVariants} className="flex justify-between items-start">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">
              Welcome back, {user?.name || 'Learner'}! 👋
            </h1>
            <p className="text-gray-400">
              Keep pushing your limits with daily DSA challenges
            </p>
          </div>
          <div className="text-right">
            <p className="text-gray-400 text-sm">Current Streak</p>
            <p className="text-4xl font-bold text-orange-400 flex items-center justify-end gap-2">
              {user?.streak || 0} 🔥
            </p>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          variants={itemVariants}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
        >
          <StatsCard
            icon={<Target className="w-6 h-6" />}
            title="Problems Solved"
            value="142"
            change="+12 this week"
            color="blue"
          />
          <StatsCard
            icon={<Zap className="w-6 h-6" />}
            title="XP Points"
            value={user?.xp || 0}
            change={`Level ${user?.level || 1}`}
            color="amber"
          />
          <StatsCard
            icon={<TrendingUp className="w-6 h-6" />}
            title="Study Time"
            value={`${Math.round((user?.total_study_time || 0) / 60)}h`}
            change="This month"
            color="emerald"
          />
          <StatsCard
            icon={<Award className="w-6 h-6" />}
            title="Achievements"
            value={achievements.length}
            change="Unlocked badges"
            color="purple"
          />
        </motion.div>

        {/* Main Content Grid */}
        <motion.div
          variants={itemVariants}
          className="grid grid-cols-1 lg:grid-cols-3 gap-6"
        >
          {/* Progress Chart */}
          <div className="lg:col-span-2 bg-gray-800/50 backdrop-blur border border-gray-700/50 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white">Progress Overview</h2>
              <select className="bg-gray-700 text-white rounded-lg px-3 py-1 text-sm border border-gray-600">
                <option>This Week</option>
                <option>This Month</option>
                <option>All Time</option>
              </select>
            </div>
            <ProgressChart topicProgress={topicProgress} />
          </div>

          {/* Recent Achievements */}
          <div className="bg-gray-800/50 backdrop-blur border border-gray-700/50 rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-6">
              <Award className="w-5 h-5 text-purple-400" />
              <h2 className="text-xl font-bold text-white">Recent Wins</h2>
            </div>
            <div className="space-y-3">
              {achievements.slice(0, 3).map((achievement) => (
                <AchievementBadge key={achievement.id} achievement={achievement} />
              ))}
              {achievements.length === 0 && (
                <p className="text-gray-400 text-sm">Start solving problems to unlock achievements!</p>
              )}
            </div>
          </div>
        </motion.div>

        {/* Activity and Topic Progress */}
        <motion.div
          variants={itemVariants}
          className="grid grid-cols-1 lg:grid-cols-3 gap-6"
        >
          {/* Activity Feed */}
          <div className="lg:col-span-2 bg-gray-800/50 backdrop-blur border border-gray-700/50 rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-6">
              <Activity className="w-5 h-5 text-blue-400" />
              <h2 className="text-xl font-bold text-white">Recent Activity</h2>
            </div>
            <ActivityFeed activities={activities} />
          </div>

          {/* Topic Progress */}
          <div className="bg-gray-800/50 backdrop-blur border border-gray-700/50 rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-6">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              <h2 className="text-xl font-bold text-white">Topics</h2>
            </div>
            <div className="space-y-4">
              {topicProgress.slice(0, 5).map((topic) => (
                <div key={topic.id}>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium text-gray-300 capitalize">
                      {topic.topic.replace('-', ' ')}
                    </span>
                    <span className="text-sm text-gray-400">
                      {topic.completion_percentage}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-blue-500 to-blue-600 h-2 rounded-full transition-all"
                      style={{ width: `${topic.completion_percentage}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Call to Action */}
        <motion.div
          variants={itemVariants}
          className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 border border-blue-500/20 rounded-2xl p-8 text-center"
        >
          <h3 className="text-2xl font-bold text-white mb-2">Ready to level up?</h3>
          <p className="text-gray-300 mb-4">Solve your next coding challenge and keep your streak alive!</p>
          <button className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-lg transition-colors">
            Start New Problem
          </button>
        </motion.div>
      </motion.div>
    </div>
  );
}
