# 📚 LeetCode AI Mentor

A production-ready AI-powered learning platform for mastering Data Structures and Algorithms using OpenAI's GPT-4 and modern web technologies.

![Next.js](https://img.shields.io/badge/Next.js-15-black?style=flat-square&logo=next.js)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?style=flat-square&logo=typescript)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-3-38b2ac?style=flat-square&logo=tailwindcss)
![Supabase](https://img.shields.io/badge/Supabase-PostgreSQL-green?style=flat-square&logo=supabase)
![OpenAI](https://img.shields.io/badge/OpenAI-GPT--4-412991?style=flat-square&logo=openai)

---

## 🎯 Features

### 1. **AI Problem Solver**
- Paste LeetCode problems or upload screenshots
- Get instant AI-generated explanations
- Brute force & optimized solutions
- Time/Space complexity analysis
- Dry run with examples
- Edge case identification

### 2. **Smart Hint System**
- 4-level progressive hint system
- Level 1: Small clue
- Level 2: Approach explanation
- Level 3: Algorithm details
- Level 4: Nearly complete solution

### 3. **Code Analyzer**
- Detect bugs and logic errors
- Syntax validation
- Optimization suggestions
- Better algorithm recommendations
- Performance analysis
- Multi-language support

### 4. **Interview Preparation**
- DSA interview questions
- System design challenges
- Behavioral questions
- AI-powered feedback
- Follow-up question suggestions

### 5. **Learning Roadmap**
- Personalized learning paths
- Beginner → Intermediate → Advanced
- Topic-based progression
- Progress tracking
- Estimated completion time

### 6. **Dashboard & Analytics**
- Problems solved counter
- Streak tracking
- Study time analytics
- Topic-wise progress
- Performance graphs
- Activity feed

### 7. **Gamification System**
- XP points for activities
- Level progression
- Achievement badges
- Leaderboard rankings
- Daily streak rewards

### 8. **Bookmark System**
- Save problems for later
- Organize into folders
- Save solutions
- Create personal notes
- Quick access to favorites

### 9. **Multi-Language Support**
- Python, Java, C++, JavaScript, TypeScript, Go
- Generate solutions in any language
- Language-specific optimizations

### 10. **Theme Support**
- Dark mode (default)
- Light mode toggle
- Smooth transitions
- Persistent preferences

---

## 🛠️ Tech Stack

### Frontend
- **Framework**: Next.js 15 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS 3
- **Components**: shadcn/ui
- **Animations**: Framer Motion
- **Icons**: Lucide Icons
- **Charts**: Recharts (for analytics)

### Backend
- **API**: Next.js API Routes
- **Runtime**: Node.js 18+
- **Server Actions**: Next.js Server Actions
- **Rate Limiting**: Custom implementation
- **Authentication**: Supabase Auth

### Database & Storage
- **Primary DB**: PostgreSQL (Supabase)
- **Auth**: Supabase Auth
- **Real-time**: Supabase Realtime
- **File Storage**: Supabase Storage

### AI & APIs
- **LLM**: OpenAI GPT-4-Turbo
- **Streaming**: OpenAI Streaming API
- **OAuth**: Google Sign-In

### Deployment
- **Hosting**: Vercel
- **CI/CD**: GitHub Actions
- **CDN**: Vercel Edge Network

---

## 📁 Project Structure

```
leetcode-ai-mentor/
├── app/                          # Next.js App Router
│   ├── dashboard/               # User dashboard
│   │   ├── problems/           # Problem solver page
│   │   ├── hints/              # Hint generator
│   │   ├── analyzer/           # Code analyzer
│   │   ├── interview/          # Interview mode
│   │   ├── roadmap/            # Learning roadmap
│   │   ├── bookmarks/          # Saved problems
│   │   └── profile/            # User profile
│   ├── api/                     # API routes
│   │   ├── ai/                # AI features
│   │   ├── problems/          # Problem CRUD
│   │   ├── solutions/         # Solution management
│   │   └── auth/              # Authentication
│   ├── auth/                    # Auth pages
│   ├── layout.tsx               # Root layout
│   └── page.tsx                 # Landing page
├── components/                  # React components
│   ├── dashboard/              # Dashboard components
│   ├── problem-solver/         # Problem solver UI
│   ├── hint-generator/         # Hint UI
│   ├── code-analyzer/          # Analyzer UI
│   ├── interview-mode/         # Interview UI
│   ├── learning-roadmap/       # Roadmap UI
│   ├── bookmarks/              # Bookmark UI
│   ├── layout/                 # Layout components
│   ├── common/                 # Shared components
│   └── ui/                     # shadcn/ui components
├── lib/                         # Utilities
│   ├── clients.ts              # Supabase & OpenAI clients
│   ├── auth.ts                 # Auth helpers
│   ├── types.ts                # TypeScript types
│   ├── ai-prompts.ts           # AI prompt templates
│   ├── rate-limit.ts           # Rate limiting
│   ├── utils.ts                # Utility functions
│   └── hooks/                  # Custom React hooks
├── styles/                      # CSS styles
├── public/                      # Static assets
├── .env.example                 # Environment template
├── DATABASE_SCHEMA.sql          # PostgreSQL schema
├── DEPLOYMENT_GUIDE.md          # Deployment instructions
├── README.md                    # This file
├── next.config.ts               # Next.js configuration
├── tailwind.config.ts           # Tailwind configuration
├── tsconfig.json                # TypeScript configuration
└── package.json                 # Dependencies
```

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- npm or yarn
- Supabase account
- OpenAI API key

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/leetcode-ai-mentor.git
cd leetcode-ai-mentor
```

2. **Install dependencies**
```bash
npm install
```

3. **Setup environment variables**
```bash
cp .env.example .env.local
```

Edit `.env.local` with your credentials:
- Supabase URL and keys
- OpenAI API key
- Google OAuth credentials (optional)

4. **Setup database**
- Go to Supabase SQL Editor
- Run `DATABASE_SCHEMA.sql`

5. **Run development server**
```bash
npm run dev
```

Visit `http://localhost:3000`

---

## 📚 Usage Examples

### Solve a Problem
```typescript
POST /api/ai/solve
{
  "problem": "Given an array of integers nums and an integer target...",
  "language": "python"
}
```

### Get Hints
```typescript
POST /api/ai/hints
{
  "problem_id": "uuid",
  "hint_level": 1
}
```

### Analyze Code
```typescript
POST /api/ai/analyze
{
  "code": "def twoSum(nums, target):\n  ...",
  "language": "python",
  "problem_context": "Two Sum"
}
```

### Start Interview Mode
```typescript
POST /api/ai/interview
{
  "question_type": "dsa",
  "difficulty": "medium",
  "topic": "arrays"
}
```

---

## 🔐 Security

### Features
- ✅ Row Level Security (RLS) on all tables
- ✅ JWT-based authentication
- ✅ Rate limiting on API endpoints
- ✅ Input validation & sanitization
- ✅ CORS protection
- ✅ Secure environment variables
- ✅ HTTPS enforcement

### Best Practices
- Never commit `.env.local`
- Use service role key only on server
- Implement rate limiting for all APIs
- Validate all user inputs
- Use prepared statements (Supabase handles this)

---

## 📊 Database Schema Highlights

### Key Tables
- `users` - User profiles and stats
- `problems` - LeetCode problems
- `solutions` - User solutions
- `hints` - Progressive hints
- `ai_explanations` - AI-generated content
- `progress` - Topic-wise progress tracking
- `achievements` - Badges and milestones
- `activity_log` - User activity tracking
- `interview_questions` - Interview prep
- `leaderboard` - User rankings

### Row Level Security
All tables have RLS policies ensuring users can only access their own data.

---

## 🎨 Design System

### Colors
- **Primary**: Blue (`#3b82f6`)
- **Secondary**: Purple (`#a855f7`)
- **Accent**: Amber (`#f59e0b`)
- **Dark**: Gray (`#111827`)

### Typography
- **Display**: Inter Bold
- **Body**: Inter Regular
- **Code**: JetBrains Mono

### Spacing
- Uses 4px base unit
- Consistent padding/margin scale
- Responsive breakpoints: sm, md, lg, xl

---

## 📈 Performance Optimizations

- ✅ Image optimization with Next.js Image
- ✅ Code splitting with dynamic imports
- ✅ Caching strategy for API responses
- ✅ Database query optimization
- ✅ Streaming responses for large payloads
- ✅ Lazy loading for components
- ✅ CSS-in-JS with Tailwind (no runtime)

---

## 🧪 Testing

### Unit Tests
```bash
npm run test
```

### Integration Tests
```bash
npm run test:integration
```

### E2E Tests
```bash
npm run test:e2e
```

---

## 📝 Environment Variables

See `.env.example` for complete reference.

**Required:**
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `OPENAI_API_KEY`

**Optional:**
- `NEXT_PUBLIC_GOOGLE_CLIENT_ID`
- `GOOGLE_CLIENT_SECRET`
- `RATE_LIMIT_REQUESTS`
- `AI_TEMPERATURE`

---

## 🚢 Deployment

### Vercel (Recommended)
```bash
vercel
```

Automatic deployment on push to main branch.

### Docker
```bash
docker build -t leetcode-ai-mentor .
docker run -p 3000:3000 leetcode-ai-mentor
```

See `DEPLOYMENT_GUIDE.md` for detailed instructions.

---

## 📚 API Documentation

All API routes return JSON responses with consistent error handling.

### Problem Solver
- `POST /api/ai/solve` - Generate solution
- `GET /api/ai/solve` - Health check

### Hints
- `POST /api/ai/hints` - Get hint
- `GET /api/ai/hints?problem_id=xxx` - Get all hints

### Code Analysis
- `POST /api/ai/analyze` - Analyze code
- `GET /api/ai/analyze/history` - Get analysis history

### Interview
- `POST /api/ai/interview` - Get question
- `POST /api/ai/interview/feedback` - Get feedback

---

## 🤝 Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

---

## 📄 License

MIT License - see LICENSE file for details

---

## 🙋 Support

- **Documentation**: https://docs.leetcode-ai-mentor.com
- **Issues**: GitHub Issues
- **Email**: support@leetcode-ai-mentor.com
- **Discord**: [Join our community](https://discord.gg/...)

---

## 🎉 Acknowledgments

Built with:
- [Next.js](https://nextjs.org) - React framework
- [Supabase](https://supabase.com) - Backend as a Service
- [OpenAI](https://openai.com) - AI models
- [Tailwind CSS](https://tailwindcss.com) - CSS framework
- [shadcn/ui](https://ui.shadcn.com) - UI components

---

## 📊 Usage Statistics

- **Functions**: 50+
- **API Routes**: 15+
- **Database Tables**: 15
- **React Components**: 30+
- **Lines of Code**: 5000+
- **TypeScript Types**: 100+

---

## 🗺️ Roadmap

- [ ] Mobile app (React Native)
- [ ] Offline mode
- [ ] Social features (follow users, share solutions)
- [ ] Video explanations
- [ ] Company-specific problems
- [ ] Practice patterns
- [ ] Mock interviews with real users
- [ ] Resume builder
- [ ] Job recommendations

---

## 📧 Contact

- **Author**: [Your Name]
- **Email**: [your.email@example.com]
- **Twitter**: [@yourhandle](https://twitter.com/yourhandle)
- **GitHub**: [yourusername](https://github.com/yourusername)

---

**Made with ❤️ for competitive programmers and learners**
